import { useState } from "react";
import InputField from "./components/InputField";
import Alert from "./components/Alert";
import Card from "./components/Card";

export default function FormUser() {
  const [nama, setNama] = useState("");
  const [paket, setPaket] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);

  const isNamaValid = nama.length >= 8;
  const isPaketSelected = paket !== "";

  // Fungsi ketika tombol Daftar diklik
  const handleSubmit = () => {
    if (isNamaValid && isPaketSelected) {
      setIsSubmitted(true);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-[#3B2F2F] p-5">
      <Card className="bg-white/95 shadow-lg rounded-lg p-6">
        <h2 className="text-3xl font-extrabold text-center text-gray-900 mb-6 tracking-wide">
          Daftar <br /> Member Gym
        </h2>

        <div className="space-y-4">
          {/* Nama Lengkap */}
          <div> 
            <label className="block text-gray-700 font-medium mb-2">
              Nama Lengkap
            </label>
            <InputField
              type="text"
              placeholder="Masukkan nama..."
              value={nama}
              onChange={(e) => setNama(e.target.value)}
            />
          </div>
          {!isNamaValid ? (
            <Alert message="Nama lengkap harus minimal 8 karakter!" type="error" />
          ) : (
            <Alert message="Nama lengkap valid!" type="success" />
          )}

          {/* Tanggal Lahir */}
          <InputField label="Tanggal Lahir" type="date" />

          {/* Nomor Telepon */}
          <InputField
            label="Nomor Telepon"
            type="number"
            placeholder="Masukkan nomor telepon..."
          />

          {/* Pilihan Paket Keanggotaan */}
          <div>
            <label className="block text-gray-700 font-medium mb-2">
              Paket Member
            </label>
            <select
              className="w-full p-3 border rounded-lg bg-gray-100 text-gray-900 focus:outline-none focus:ring-2 focus:ring-brown-600"
              value={paket}
              onChange={(e) => setPaket(e.target.value)}
            >
              <option value="">Pilih Paket...</option>
              <option value="Bulanan">Bulanan</option>
              <option value="Tahunan">Tahunan</option>
            </select>
          </div>
          {!isPaketSelected ? (
            <Alert message="Silakan pilih paket terlebih dahulu!" type="error" />
          ) : (
            <Alert message={`Paket ${paket} dipilih!`} type="success" />
          )}
        </div>

        {/* Tombol Daftar */}
        <button
          onClick={handleSubmit}
          className="w-full bg-gradient-to-r from-[#5A3E2B] to-[#B08D57] 
                  hover:from-[#6B4F3F] hover:to-[#C4A484] text-white p-3 rounded-2xl font-semibold transition duration-300 hover:shadow-lg hover:shadow-brown-500/50 transform hover:scale-105 mt-6"
        >
          Daftar Sekarang
        </button>

        {/* Pesan Sukses Setelah Klik */}
        {isSubmitted && (
          <Alert message="🎉 Pendaftaran berhasil! Selamat bergabung di Gym KokoSten punya!" type="success" />
        )}
      </Card>
    </div>
  );
}
